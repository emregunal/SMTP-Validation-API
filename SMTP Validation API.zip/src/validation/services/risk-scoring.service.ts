import { Injectable } from '@nestjs/common';
import { EmailStatus } from '../../common/enums/email-status.enum';
import { EmailSubStatus } from '../../common/enums/email-sub-status.enum';
import { RiskLevel } from '../../common/enums/risk-level.enum';
import {
  RiskEvaluation,
  ValidationContext,
} from '../../common/types/validation.types';

/**
 * Turns the accumulated ValidationContext into a final status/sub-status,
 * a 0-100 score and a risk level.
 *
 * Checks are evaluated in strict priority order (most critical first):
 *
 *   syntax invalid > disposable > dns error/timeout > no DNS > null MX >
 *   no MX > possible typo > role-based > mx found (deliverable)
 *
 * Note: this MVP performs NO SMTP mailbox verification, so even a "deliverable"
 * result is only asserting DNS/MX-level reachability.
 */
@Injectable()
export class RiskScoringService {
  private static readonly MVP_NOTE =
    'SMTP check might be skipped if not enabled. When enabled, it provides an additional signal.';

  evaluate(context: ValidationContext): RiskEvaluation {
    // 1. Syntax
    if (!context.syntax.valid) {
      return this.build(
        0,
        EmailStatus.UNDELIVERABLE,
        EmailSubStatus.FAILED_SYNTAX_CHECK,
        context.syntax.reason ?? 'Email failed the syntax check.',
      );
    }

    // Defensive: syntax passed but domain could not be parsed.
    if (!context.domainInfo) {
      return this.build(
        0,
        EmailStatus.UNDELIVERABLE,
        EmailSubStatus.INVALID_DOMAIN_FORMAT,
        'Domain has an invalid format.',
      );
    }

    // 2. Disposable
    if (context.disposable) {
      return this.build(
        5,
        EmailStatus.DO_NOT_MAIL,
        EmailSubStatus.DISPOSABLE,
        'Domain is a known disposable/throwaway email provider.',
      );
    }

    const dns = context.dns;

    // 3. DNS lookup failed/timed out -> we genuinely cannot tell.
    if (!dns || dns.error || dns.timedOut) {
      return this.build(
        40,
        EmailStatus.UNKNOWN,
        EmailSubStatus.UNKNOWN_ERROR,
        'DNS lookup failed or timed out; deliverability could not be determined.',
      );
    }

    // 4. No DNS entries at all
    if (!dns.dnsFound) {
      return this.build(
        0,
        EmailStatus.UNDELIVERABLE,
        EmailSubStatus.NO_DNS_ENTRIES,
        'Domain has no DNS records.',
      );
    }

    // 5. Null MX (domain explicitly rejects mail)
    if (dns.nullMx) {
      return this.build(
        0,
        EmailStatus.UNDELIVERABLE,
        EmailSubStatus.NULL_MX,
        'Domain explicitly does not accept email.',
      );
    }

    // 6. DNS exists but no usable MX record
    if (!dns.mxFound) {
      return this.build(
        20,
        EmailStatus.UNDELIVERABLE,
        EmailSubStatus.NO_MX_RECORDS,
        'Domain has DNS records but no MX records.',
      );
    }

    // --- from here on MX is present ---

    // 7. Check History (Bounce Feedback)
    if (context.history && context.history.status === 'found') {
      const hist = context.history;
      if (hist.hardBounceCount > 0) {
        return this.build(
          0,
          EmailStatus.UNDELIVERABLE,
          EmailSubStatus.PREVIOUS_HARD_BOUNCE,
          'Previous hard bounce recorded. Mailbox does not exist.',
        );
      }
    }

    let score = 100;
    let status = EmailStatus.DELIVERABLE;
    let subStatus: EmailSubStatus | null = EmailSubStatus.MX_FOUND;
    let reason = '';

    // History bonus / penalty
    let historyReason = '';
    if (context.history && context.history.status === 'found') {
      const hist = context.history;
      if (hist.deliveredCount > 0 && hist.confidenceImpact === 'high') {
        historyReason = ' Previous successful delivery recorded.';
        // We can't exceed 100, but it boosts confidence
      } else if (hist.confidenceImpact === 'medium' || hist.confidenceImpact === 'low') {
        score -= 20;
        historyReason = ' Previous negative engagements (soft bounces or complaints) recorded.';
      }
    }

    // Base adjustments
    if (context.domainInfo.freeEmail) score -= 5;
    if (context.domainInfo.corporateEmail) score += 5;

    // Evaluate Domain Behavior Cache
    let behaviorReason = '';
    if (context.domainBehavior && context.domainBehavior.status === 'known') {
      const behavior = context.domainBehavior;
      
      if (behavior.catchAllObserved) {
        // If we already know this domain is a catch-all, we don't need a new test
        score = Math.min(score, 60);
        status = EmailStatus.RISKY;
        subStatus = EmailSubStatus.CATCH_ALL;
        behaviorReason = ' Domain is historically known to be a catch-all.';
        context.domainBehavior.confidenceImpact = 'lowered';
      } else if (behavior.recentTempfailRate > 0.5) {
        // If it constantly tempfails, we lower confidence
        score -= 15;
        behaviorReason = ' Domain has a history of high tempfail/timeout rates.';
        context.domainBehavior.confidenceImpact = 'lowered';
      }
    }

    // Evaluate Catch-All if present (and not already flagged by behavior)
    let catchAllReason = '';
    let isCatchAll = false;
    if (context.catchAll) {
      if (context.catchAll.status === 'detected' || context.catchAll.status === 'possible') {
        score = Math.min(score, 60);
        status = EmailStatus.RISKY;
        subStatus = EmailSubStatus.CATCH_ALL;
        catchAllReason = ' Domain is configured as a catch-all, making mailbox verification inconclusive.';
        isCatchAll = true;
      } else if (context.catchAll.status === 'unknown') {
        // We tried but couldn't verify
        score -= 5;
        catchAllReason = ' Catch-all verification was inconclusive.';
      } else if (context.catchAll.status === 'not_detected') {
        // Random address rejected, this is a strong signal that target is valid
        score += 5;
        catchAllReason = ' Domain correctly rejects random addresses (no catch-all).';
      }
    }

    // Evaluate SMTP signal if present and not skipped
    let smtpReason = '';
    if (context.smtp && context.smtp.status !== 'skipped') {
      const smtp = context.smtp;
      if (smtp.status === 'accepted') {
        if (!isCatchAll && !(context.domainBehavior?.catchAllObserved)) {
          if (smtp.provider === 'corporate') {
            score = Math.min(score, 80);
            status = EmailStatus.RISKY;
            subStatus = EmailSubStatus.POSSIBLE_CATCH_ALL;
            smtpReason = ' SMTP server accepted the address, but corporate domains often use catch-all.';
          } else {
            score += 10;
            smtpReason = ' SMTP server accepted the recipient address.';
          }
        } else {
          smtpReason = ' SMTP server accepted the address.';
        }
      } else if (smtp.status === 'rejected') {
        score -= 80;
        if (smtp.providerRiskProfile === 'strict') {
          score = 0;
        }
        status = EmailStatus.UNDELIVERABLE;
        smtpReason = ` SMTP server rejected the address (${smtp.code || 'rejected'}).`;
      } else if (smtp.status === 'blocked') {
        score -= 40;
        status = EmailStatus.RISKY;
        smtpReason = ` SMTP connection was blocked by policy (${smtp.code || 'blocked'}).`;
      } else {
        // tempfail, timeout, connection_failed, unknown
        if (smtp.provider === 'enterprise_gateway' && (smtp.status === 'timeout' || smtp.status === 'connection_failed' || smtp.status === 'tempfail')) {
          score -= 20;
          status = EmailStatus.UNKNOWN;
          subStatus = EmailSubStatus.TARPIT_SUSPECTED;
          smtpReason = ` Enterprise gateway suspected of tarpitting or firewall block (${smtp.status}).`;
        } else if ((smtp.provider === 'gmail' || smtp.provider === 'outlook') && smtp.status === 'tempfail') {
          score -= 10;
          status = EmailStatus.UNKNOWN;
          smtpReason = ` Provider tempfail likely due to IP reputation (${smtp.status}).`;
        } else {
          score -= 20;
          status = EmailStatus.UNKNOWN;
          smtpReason = ` SMTP validation was inconclusive (${smtp.status}).`;
        }
      }
    }

    // 7. Possible typo of a popular provider
    if (context.typoSuggestedDomain) {
      const suggested = context.localPart
        ? `${context.localPart}@${context.typoSuggestedDomain}`
        : context.typoSuggestedDomain;
      
      // If SMTP already rejected, keep that status but add typo info
      if (status !== EmailStatus.UNDELIVERABLE) {
        status = EmailStatus.UNDELIVERABLE;
        score = Math.min(score, 20);
        subStatus = EmailSubStatus.POSSIBLE_TYPO;
      }
      reason = `Domain looks like a typo of a popular provider. Did you mean ${suggested}?`;
    } 
    // 8. Role-based address (info@, support@, ...)
    else if (context.roleBased) {
      if (status !== EmailStatus.UNDELIVERABLE) {
        status = EmailStatus.RISKY;
        score = Math.min(score, 55);
        subStatus = EmailSubStatus.ROLE_BASED;
      }
      reason = `Role-based address (e.g. info@, support@); may not map to a person.`;
    }

    reason += smtpReason + catchAllReason + behaviorReason + historyReason;
    reason = `${reason.trim()} ${RiskScoringService.MVP_NOTE}`.trim();

    return this.build(score, status, subStatus, reason);
  }

  /** Maps a 0-100 score to a risk bucket. */
  scoreToRisk(score: number): RiskLevel {
    if (score <= 30) return RiskLevel.HIGH;
    if (score <= 60) return RiskLevel.MEDIUM;
    if (score <= 84) return RiskLevel.LOW;
    return RiskLevel.VERY_LOW;
  }

  private build(
    score: number,
    status: EmailStatus,
    subStatus: EmailSubStatus,
    reason: string,
  ): RiskEvaluation {
    const clamped = this.clamp(score);
    return {
      score: clamped,
      risk: this.scoreToRisk(clamped),
      status,
      subStatus,
      reason,
    };
  }

  private clamp(score: number): number {
    return Math.max(0, Math.min(100, Math.round(score)));
  }
}
