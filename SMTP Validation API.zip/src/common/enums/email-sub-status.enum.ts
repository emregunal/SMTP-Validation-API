/**
 * Fine-grained reason attached to an EmailStatus.
 */
export enum EmailSubStatus {
  FAILED_SYNTAX_CHECK = 'failed_syntax_check',
  INVALID_DOMAIN_FORMAT = 'invalid_domain_format',
  NO_DNS_ENTRIES = 'no_dns_entries',
  NO_MX_RECORDS = 'no_mx_records',
  NULL_MX = 'null_mx',
  MX_FOUND = 'mx_found',
  DISPOSABLE = 'disposable',
  ROLE_BASED = 'role_based',
  POSSIBLE_TYPO = 'possible_typo',
  FREE_EMAIL = 'free_email',
  CORPORATE_EMAIL = 'corporate_email',
  UNKNOWN_ERROR = 'unknown_error',
  TARPIT_SUSPECTED = 'tarpit_suspected',
  POSSIBLE_CATCH_ALL = 'possible_catch_all',
  CATCH_ALL = 'catch_all',
  PREVIOUS_HARD_BOUNCE = 'previous_hard_bounce',
}
