import { Injectable } from '@nestjs/common';
import { EmailProvider, ProviderRiskProfile, SmtpSignal, SmtpStatus } from '../../common/types/validation.types';

@Injectable()
export class SmtpResponseParser {
  /**
   * Parses raw SMTP response parts into an SmtpSignal.
   */
  parse(
    status: SmtpStatus,
    rawMessage: string | null,
    provider: EmailProvider,
    providerRiskProfile: ProviderRiskProfile,
    mxHost: string | null,
    durationMs: number,
  ): SmtpSignal {
    const signal: SmtpSignal = {
      status,
      code: null,
      enhancedCode: null,
      message: null,
      provider,
      providerRiskProfile,
      mxHost,
      durationMs,
    };

    if (!rawMessage) {
      return signal;
    }

    // Clean up message
    const lines = rawMessage.split('\n').map((l) => l.trim()).filter((l) => l.length > 0);
    const lastLine = lines[lines.length - 1] || rawMessage;
    
    // Extract code (e.g. "550", "250")
    const codeMatch = lastLine.match(/^(\d{3})(?:[\s-]|$)/);
    if (codeMatch) {
      signal.code = parseInt(codeMatch[1], 10);
    }

    // Extract enhanced status code if present (e.g. "5.1.1")
    const enhancedMatch = lastLine.match(/\b([245]\.\d{1,3}\.\d{1,3})\b/);
    if (enhancedMatch) {
      signal.enhancedCode = enhancedMatch[1];
    }

    // Extract textual message
    // Usually after the code and enhanced code. We just take the whole last line for simplicity,
    // or strip the prefix. Let's just use the last line, maybe stripping the "250-" prefix.
    const messageMatch = lastLine.match(/^\d{3}[\s-](?:[245]\.\d{1,3}\.\d{1,3}[\s-])?(.*)$/);
    if (messageMatch) {
      signal.message = messageMatch[1].trim();
    } else {
      signal.message = lastLine;
    }

    // Attempt to refine the status based on the parsed code if the initial status wasn't definitive,
    // or if we have more specific policy logic.
    if (signal.code) {
      if (signal.code >= 200 && signal.code < 300) {
        signal.status = 'accepted';
      } else if (signal.code >= 400 && signal.code < 500) {
        // tempfail, greylisting, etc.
        signal.status = 'tempfail';
      } else if (signal.code >= 500 && signal.code < 600) {
        // Determine if it's a policy block vs user unknown
        // Common policy blocks: 554, or "Spam", "Blocked", "Blacklisted" in message
        const lowerMsg = signal.message.toLowerCase();
        if (
          signal.code === 554 ||
          lowerMsg.includes('block') ||
          lowerMsg.includes('spam') ||
          lowerMsg.includes('blacklis') ||
          lowerMsg.includes('banned') ||
          lowerMsg.includes('policy')
        ) {
          signal.status = 'blocked';
        } else {
          signal.status = 'rejected';
        }
      }
    }

    return signal;
  }
}
